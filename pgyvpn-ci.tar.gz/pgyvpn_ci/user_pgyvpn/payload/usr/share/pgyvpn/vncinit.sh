#!/bin/sh
#由于oray_vnc的mtu比较小，所以所有转发进出oray_vnc网卡的
#tcp连接需要对其MSS做修正，以适合其MTU，否则可能出现大数据
#被丢弃的现象
orayvnc_mss_fix()
{
	local IPTBL_CMD=
	local IPTBL_MSS_TBL=
		
	IPTBL_CMD="iptables -t mangle"
	IPTBL_MSS_TBL='orayvnc_mssfix'
	
	#清空子表
	$IPTBL_CMD -D FORWARD -j $IPTBL_MSS_TBL
	$IPTBL_CMD -F $IPTBL_MSS_TBL
	$IPTBL_CMD -X $IPTBL_MSS_TBL
	
	#重新建立新表并填充mss相关规则
	$IPTBL_CMD -N $IPTBL_MSS_TBL
	$IPTBL_CMD -A $IPTBL_MSS_TBL -o oray_vnc -p tcp --tcp-flags SYN,RST SYN -j TCPMSS --clamp-mss-to-pmtu
	$IPTBL_CMD -A $IPTBL_MSS_TBL -i oray_vnc -p tcp --tcp-flags SYN,RST SYN -j TCPMSS --clamp-mss-to-pmtu
	$IPTBL_CMD -A FORWARD -j $IPTBL_MSS_TBL
}

orayvnc_mss_fix >/dev/null 2>&1

#删除oray_vpn_vnc表
iptables -t filter -F oray_vpn_vnc
while true;
do
	iptables -t filter -D INPUT -j oray_vpn_vnc 2>/dev/null
	[ $? -ne 0 ] && break
done

while true;
do
	iptables -t filter -D FORWARD -j oray_vpn_vnc 2>/dev/null
	[ $? -ne 0 ] && break
done

while true;
do
	iptables -t filter -D OUTPUT -j oray_vpn_vnc 2>/dev/null
	[ $? -ne 0 ] && break
done

iptables -t filter -X oray_vpn_vnc

#建立oray_vpn_vnc表
iptables -t filter -N oray_vpn_vnc

#放行所有的转发
iptables -t filter -I oray_vpn_vnc -i oray_vnc -j ACCEPT
iptables -t filter -I oray_vpn_vnc -o oray_vnc -j ACCEPT

iptables -t filter -I INPUT 1 -j oray_vpn_vnc
iptables -t filter -I OUTPUT 1 -j oray_vpn_vnc
iptables -t filter -I FORWARD 1 -j oray_vpn_vnc

#---- 让 LAN 侧经隧道访问组网对端时把源地址改写成隧道地址 ----
# 对端的 WAN 常常与本机 LAN 处于同一网段（如 192.168.88.0/24），
# 不做 NAT 时对端会把回包从自己的 WAN 直接发回，回包不走隧道，
# 形成非对称路由，表现为“能 ping 通但打不开网页”。
while true; do
	iptables -t nat -D POSTROUTING -o oray_vnc -j MASQUERADE 2>/dev/null
	[ $? -ne 0 ] && break
done
iptables -t nat -A POSTROUTING -o oray_vnc -j MASQUERADE
