#!/bin/sh

#全局变量，表示当前脚本所在绝对路径
cur_abs_path=$(cd "$(dirname "$0")"; pwd)

#加载common.sh，方便后续调用一些常用函数
. $cur_abs_path/common.sh

action=$1

lockfile=$cur_abs_path/ini.lock

if [ $action == 'get' ];then
    ret=""
    {
        flock -s 200
        ret=$(ReadIni $2 $3 $4)
        if [ $? -ne 0 ];then
            write_log "ReadIni $2 $3 $4 err"
        fi
    } 200>$lockfile
    echo $ret
    exit 0
fi

if [ $action == 'set' ];then
    {
        flock -x 200
        ret=$(WriteIni $2 $3 $4 $5)
        if [ $? -ne 0 ];then
            write_log "WriteIni $2 $3 $4 $5 err"
        fi
    } 200>$lockfile
    exit 0
fi

exit 1

