<!DOCTYPE html>
<html>
<head>
<title>蒲公英</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="-1">

<link rel="shortcut icon" href="images/favicon.ico">
<link rel="icon" href="images/favicon.ico">
<link rel="stylesheet" type="text/css" href="/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="/bootstrap/css/main.css">

<script type="text/javascript" src="/jquery.js"></script>
<script type="text/javascript" src="/state.js"></script>
<script type="text/javascript" src="/general.js"></script>
<script type="text/javascript" src="/popup.js"></script>
<script>

<% login_state_hook(); %>

var $j = jQuery.noConflict();

var busy = false;
var poll_timer = null;
var poll_left = 0;

function initial(){
	try { show_banner(1); } catch (e) {}
	/* 自动定位自己在「穿透服务」组里的位置（不同 fork 组索引不同，全部扫一遍） */
	var pgy_l2 = 0, pgy_l3 = 2, pgy_g, pgy_i;
	try {
		for (pgy_g = 0; pgy_g < 32 && !pgy_l2; pgy_g++) {
			if (typeof tablink[pgy_g] == "undefined" || !tablink[pgy_g]) continue;
			for (pgy_i = 1; pgy_i < tablink[pgy_g].length; pgy_i++) {
				if (tablink[pgy_g][pgy_i] == "pgyvpn.asp") {
					pgy_l3 = pgy_i;
					/* 二级菜单里指向本组第一页的就是这一组的槽 */
					if (typeof menuL2_link != "undefined") {
						var q;
						for (q = 0; q < menuL2_link.length; q++) {
							if (menuL2_link[q] == tablink[pgy_g][1]) { pgy_l2 = q; break; }
						}
					}
					if (!pgy_l2) pgy_l2 = pgy_g + 1;
					break;
				}
			}
		}
	} catch (e) {}
	if (!pgy_l2) pgy_l2 = 17;
	try { show_menu(5, pgy_l2, pgy_l3); } catch (e) {}
	try { show_footer(); } catch (e) {}
	refresh_status();
	setTimeout(function(){ pgy_routes_load(); }, 2500);
}

function set_box(text, kind){
	var el = $j('#pgy_box');
	el.removeClass('alert-success alert-info alert-warning alert-danger');
	el.addClass(kind || 'alert-info');
	el.text(text);
}

function val(id){
	return $j('#' + id).val() || '';
}

/* 固件 apply.cgi 只把命令存进 nvram，执行发生在随后 GET response 页时 */
function post_cmd(cmd, ok, fail){
	$j.ajax({
		url: '/apply.cgi',
		type: 'POST',
		data: {
			'action_mode': ' SystemCmd ',
			'current_page': 'pgyvpn_response.asp',
			'next_page': 'pgyvpn_response.asp',
			'SystemCmd': cmd
		},
		cache: false,
		dataType: 'text',
		success: function(){ if (ok) ok(); },
		error: function(xhr){
			busy = false;
			stop_poll();
			var msg = '请求失败（HTTP ' + xhr.status + '）。' +
				(xhr.status === 401 ? '请先登录路由器管理后台。' : '');
			if (fail) fail(msg); else set_box(msg, 'alert-danger');
		}
	});
}

function fetch_out(done){
	$j.ajax({
		url: '/pgyvpn_response.asp',
		type: 'GET',
		cache: false,
		data: { _: (new Date()).getTime() },
		dataType: 'text',
		success: function(data){
			var t = $j.trim(data || '');
			if (!t) t = '（无输出）';
			var kind = 'alert-info';
			if (t.indexOf('已组网') >= 0) kind = 'alert-success';
			else if (t.indexOf('登录失败') >= 0 || t.indexOf('未运行') >= 0 || t.indexOf('未知') >= 0) kind = 'alert-warning';
			set_box(t, kind);
			fill_account_from(t);
			if (done) done(t);
		},
		error: function(){ busy = false; stop_poll(); set_box('读取执行结果失败。', 'alert-warning'); }
	});
}

function stop_poll(){
	if (poll_timer) { clearTimeout(poll_timer); poll_timer = null; }
	poll_left = 0;
}

function refresh_status(keep_busy){
	if (busy && !keep_busy) return false;
	busy = true;
	if (!keep_busy) set_box('正在读取状态…', 'alert-info');
	post_cmd('/usr/bin/pgyvpn_status.sh', function(){
		setTimeout(function(){
			fetch_out(function(t){
				busy = false;
				if (keep_busy){
					if (t.indexOf('已组网') >= 0 || t.indexOf('未加入组网') >= 0 || poll_left <= 0){
						stop_poll();
					} else {
						poll_left--;
						poll_timer = setTimeout(function(){ refresh_status(true); }, 4000);
					}
				}
			});
		}, 300);
	});
	return false;
}

function start_poll(text){
	stop_poll();
	poll_left = 8;
	busy = true;
	set_box(text, 'alert-info');
	poll_timer = setTimeout(function(){ refresh_status(true); }, 3000);
}

function clean(s){
	return s.replace(/'/g, '').replace(/"/g, '').replace(/ /g, '');
}

/* ---- 对端静态路由：读写 /etc/storage/pgyvpn_peer_routes ---- */
var routes_busy = false;

function pgy_routes_fill(text){
	$j('#pgy_routes').val($j.trim((text || '').replace('（无输出）', '')));
}

function pgy_routes_get(done){
	$j.ajax({
		url: '/pgyvpn_response.asp',
		type: 'GET',
		cache: false,
		data: { _: (new Date()).getTime() },
		dataType: 'text',
		success: function(d){ done(d); },
		error: function(){ routes_busy = false; $j('#pgy_routes_note').text('读取结果失败。'); }
	});
}

function pgy_routes_load(){
	if (routes_busy) return false;
	routes_busy = true;
	$j('#pgy_routes_note').text('正在读取…');
	post_cmd('/etc/storage/pgyvpn_route.sh list', function(){
		setTimeout(function(){
			pgy_routes_get(function(d){
				busy = false;
				routes_busy = false;
				pgy_routes_fill(d);
				$j('#pgy_routes_note').text('已读取当前静态路由。');
			});
		}, 300);
	});
	return false;
}

function pgy_routes_save(){
	if (routes_busy) return false;
	var lines = ($j('#pgy_routes').val() || '').split(/\r?\n/);
	var args = [];
	for (var i = 0; i < lines.length; i++){
		var ln = $j.trim(lines[i]);
		if (!ln || ln.charAt(0) === '#') continue;
		var p = ln.split(/\s+/);
		var dst = p[0];
		var gw = p[1] || '';
		if (dst.indexOf('/') < 0){
			$j('#pgy_routes_note').text('第 ' + (i + 1) + ' 行格式不对，应形如 192.168.2.0/24 172.16.2.35');
			return false;
		}
		args.push(gw ? (dst + ':' + gw) : dst);
	}
	var cmd = '/etc/storage/pgyvpn_route.sh set ' + args.join(' ');
	routes_busy = true;
	$j('#pgy_routes_note').text('正在保存…');
	post_cmd(cmd, function(){
		setTimeout(function(){
			pgy_routes_get(function(d){
				busy = false;
				routes_busy = false;
				$j('#pgy_routes_note').text($j.trim(d || '已保存。'));
				pgy_routes_fill('');
				routes_busy = true;
				post_cmd('/etc/storage/pgyvpn_route.sh list', function(){
					setTimeout(function(){
						pgy_routes_get(function(d2){ routes_busy = false; pgy_routes_fill(d2); });
					}, 300);
				});
			});
		}, 300);
	});
	return false;
}

/* 用状态输出里的“账号: xxx”回填输入框（避免页面写死旧账号造成“重启后变回旧账号”的错觉） */
function fill_account_from(t){
	var m = /账号[:：]\s*([^\s]+)/.exec(t || '');
	if (!m) return;
	var box = $j('#pgy_acc');
	var cur = $j.trim(box.val() || '');
	if (!cur || box.attr('data-auto') === '1'){
		box.val(m[1]);
		box.attr('data-auto', '1');
	}
}
$j(function(){ $j('#pgy_acc').on('input', function(){ $j(this).attr('data-auto', '0'); }); });

function pgy_login(){
	if (busy) return false;
	var acc = clean(val('pgy_acc'));
	var pwd = clean(val('pgy_pwd'));
	if (!acc){ set_box('请填写账号（设备 SN）。', 'alert-warning'); return false; }
	var cmd = '/etc/storage/pgyvpn_login.sh restart \'' + acc + '\'';
	if (pwd) cmd += ' \'' + pwd + '\'';
	busy = true;
	set_box('正在提交登录…', 'alert-info');
	$j('#pgy_pwd').val('');
	post_cmd(cmd, function(){
		fetch_out(function(){ start_poll('已提交登录，等待组网建立（最长约 30 秒）…'); });
	});
	return false;
}

function pgy_logout(){
	if (busy) return false;
	busy = true;
	set_box('正在提交退出…', 'alert-info');
	post_cmd('/etc/storage/pgyvpn_login.sh stop', function(){
		fetch_out(function(){ start_poll('已提交退出，正在确认状态…'); });
	});
	return false;
}
</script>
</head>

<body onLoad="initial();">
<div class="wrapper">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span3"><center><div id="logo"></div></center></div>
			<div class="span9"><div id="TopBanner"></div></div>
		</div>
		<div class="row-fluid">
			<div class="span3">
				<div class="well sidebar-nav side_nav" style="padding: 0px;">
					<ul id="mainMenu" class="clearfix"></ul>
					<ul id="subMenu" class="accordion"></ul>
				</div>
			</div>
			<div class="span9">
				<div class="row-fluid">
					<div class="span12">
						<div class="box well grad_colour_dark_blue">
							<h2 class="box_head round_top">穿透服务 - 蒲公英</h2>
							<div class="round_bottom">
								<div class="row-fluid">
									<div id="tabMenu" class="submenuBlock"></div>
									<div class="span12" style="padding: 10px 15px 0 15px;">

										<div id="pgy_box" class="alert alert-info" style="white-space: pre-wrap; font-family: 'Courier New', Courier, monospace; margin-bottom: 12px;">读取中…</div>

										<table class="table table-bordered" style="max-width: 720px; margin-bottom: 12px;">
											<tr>
												<td style="width: 22%">账号（设备 SN）</td>
												<td><input type="text" id="pgy_acc" class="span10" style="height: 26px;" value="" placeholder="P 开头的设备 SN（留空自动填入已保存的账号）"></td>
											</tr>
											<tr>
												<td>密码</td>
												<td>
													<input type="password" id="pgy_pwd" class="span10" style="height: 26px;" value="" placeholder="留空则沿用已保存的密码">
													<span class="help-block" style="margin: 4px 0 0 0; font-size: 12px;">填写后会写入 <code>/etc/storage/pgyvpn/account.conf</code> 并保存到 flash；留空则用现有凭据。</span>
												</td>
											</tr>
										</table>

										<div class="btn-group" style="margin-bottom: 15px;">
											<button class="btn btn-primary" type="button" onclick="return pgy_login();"><i class="icon icon-play"></i> 登录</button>
											<button class="btn btn-danger" type="button" onclick="return pgy_logout();"><i class="icon icon-stop"></i> 退出</button>
											<button class="btn" type="button" onclick="return refresh_status();"><i class="icon icon-refresh"></i> 刷新状态</button>
										</div>

										<table class="table table-bordered" style="max-width: 720px;">
											<tr><td style="width: 22%">登录</td><td><code>/etc/storage/pgyvpn_login.sh restart [账号] [密码]</code></td></tr>
											<tr><td>退出</td><td><code>/etc/storage/pgyvpn_login.sh stop</code></td></tr>
											<tr><td>状态文件</td><td><code>/tmp/orayboxvpn_connect_status</code></td></tr>
											<tr><td>隧道网卡</td><td><code>oray_vnc</code></td></tr>
										</table>

<h3 style="font-size: 15px; margin: 16px 0 8px 0;">对端静态路由（可自定义）</h3>
																		<p class="help-block" style="margin: 0 0 8px 0;">每行一条，格式：<code>目标网段 网关</code>，例如 <code>192.168.2.0/24 172.16.2.35</code>。保存后立即生效，并写入 <code>/etc/storage/pgyvpn_peer_routes</code>，重启后自动重建。</p>
																		<textarea id="pgy_routes" rows="5" style="width: 640px; font-family: 'Courier New', Courier, monospace;" placeholder="192.168.2.0/24 172.16.2.35"></textarea>
																		<div class="btn-group" style="margin: 8px 0 4px 0;">
																			<button class="btn" type="button" onclick="return pgy_routes_load();"><i class="icon icon-refresh"></i> 读取当前路由</button>
																			<button class="btn btn-primary" type="button" onclick="return pgy_routes_save();"><i class="icon icon-ok icon-white"></i> 保存并应用</button>
																		</div>
																		<div id="pgy_routes_note" class="help-block" style="margin: 0 0 14px 0;"></div>

																												<div class="alert alert-warning" style="max-width: 720px;">
											状态里显示的“组网 IP”就是本机在蒲公英组网内的虚拟地址；要真正互通，还需在蒲公英云平台把这台 SN 加进组网。
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
	<div id="Loading" class="popup_bg"></div>
</body>
</html>
