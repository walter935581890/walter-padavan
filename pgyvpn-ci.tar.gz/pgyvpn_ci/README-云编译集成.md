# 把蒲公英(pgyvpn)接进 padavan-4.4 云编译

针对 `https://github.com/walter935581890/padavan-4.4`（hanwckf padavan-4.4 系）。
目标：push/手动触发 GitHub Actions 时，产出的 `.trx` 里已经带蒲公英管理页，不用再事后注入。

---

## 一、三步上手

```bash
# 1. 克隆你的仓库到本地
git clone https://github.com/walter935581890/padavan-4.4 && cd padavan-4.4

# 2. 打补丁（把本目录里的东西铺进源码树）
sh /path/to/pgyvpn-ci/apply.sh .

# 3. 提交
git add -A && git commit -m "add pgyvpn (蒲公英 VPN) support" && git push
```

推上去之后：**Actions → Build Padavan + pgyvpn → Run workflow**，填型号（默认 `MI-R3G B70`），勾 `pgyvpn=1`，跑完在 Artifacts 里拿 trx。

本地编译等价写法：

```bash
cd trunk
PGYVPN=y fakeroot ./build_firmware_modify MI-R3G
```

---

## 二、apply.sh 到底改了哪 5 处

| 文件 | 改动 | 原因 |
|---|---|---|
| `trunk/user/pgyvpn/`（新增） | 整棵 payload + Makefile | 插件本体：`/usr/sbin/pgyvpn`、`/usr/lib/pgyvpn`、`/usr/share/pgyvpn`、`/usr/bin/pgyvpn_*.sh`、`/lib/ld-musl-mipsel-sf.so.1`、两个 asp |
| `trunk/user/Makefile` | `dir_$(CONFIG_FIRMWARE_INCLUDE_PGYVPN) += pgyvpn`（在 `scripts` 之后） | 让 `make romfs` 把插件铺进 romfs；**必须排在 `www` 之后**，否则 www 重建会把页面冲掉 |
| `trunk/build_firmware_modify` | 读环境变量 `PGYVPN=y` 就往 `.config` 追加开关 | 一个开关控制编不编，默认关，不影响你其他型号 |
| `trunk/user/scripts/dev_init.sh` | `mtd_storage.sh fill` 之后调 `/usr/bin/pgyvpn_install.sh` | 开机把凭据/路由/自愈脚本铺到 `/etc/storage`（`/etc` 是 tmpfs，`/usr` 只读） |
| `trunk/user/www/n56u_ribbon_fixed/state.js` | 高级菜单组 6 末尾追加「蒲公英 VPN」→ `pgyvpn.asp` | 页面在固件里但没菜单项等于没有 |

另外新增 `.github/workflows/build-pgyvpn.yml`。

---

## 三、验证记录（本次实测过的，不是推演）

- `sh apply.sh` 在干净 clone 上跑通，四处补丁全部命中，`git diff` 内容正确
- `make -C trunk/user/pgyvpn romfs` 单独跑过：25 个文件落到 romfs 对应路径，`lib/ld-musl-mipsel-sf.so.1` 软链保留，脚本权限 755
- `state.js` 追加后数组长度 7，`pgyvpn.asp` 里是 `show_menu(5, 7, 7)`，与菜单项数吻合
- `dev_init.sh`、`pgyvpn_install.sh` 均通过 `sh -n` 语法检查
- 完整的 cloud build 未在本机跑（要下 100MB+ 工具链、编 30–60 分钟），首次跑 workflow 时留意日志里有没有 `Install pgyvpn (蒲公英 VPN)`

---

## 四、体积与型号（最容易翻车的地方）

payload 12MB，xz 压完约 +2.5MB。16MB flash 的机器（MI-R3G/B70 这类）本来就紧张，而你 `build_firmware_modify` 里的默认配置还开着 xray（约 4.5MB）、trojan、adbyby。

编译前建议先把大件关掉，两种办法：

1. 改 `build_firmware_modify` 里那几行 `echo "CONFIG_FIRMWARE_INCLUDE_XRAY=y"` → `n`（影响所有云编译）
2. 或在 workflow 的 Build 步骤里，进 `trunk` 后对 `.config` 做 sed（只影响这次构建）

产物出来后 workflow 会打印每个 trx 的字节数和 MB 数，**≥ 16MB(16777216) 就别刷**，先裁组件。

---

## 五、还要注意的三件事

1. **架构**：payload 是 `mipsel` + musl 的二进制，只适用于 MT7620/7621 这类 MIPS 机型。ARM 平台要换对应架构的 pgyvpn 包。
2. **内核 TUN**：pgyvpn 走 TUN 设备。本仓库各板 `configs/boards/*/kernel-4.4.x.config` 里基本都是 `CONFIG_TUN=y`，换新型号时确认一下。
3. **storage 不会被刷掉**：刷机只换 squashfs，`/etc/storage` 里的旧账号、旧路由仍在。本次 v7 插件首次开机会自动清掉旧固件写死的那条 `192.168.2.0/24 172.16.2.35`（靠 `/etc/storage/pgyvpn/.route_legacy_cleared` 标记，只做一次）。

---

## 六、刷完自检

- `http://设备IP/pgyvpn.asp` 打得开，高级菜单里能看到「蒲公英 VPN」
- 填账号点登录 → 状态 `connected`，页面显示组网 IP（如 `172.16.1.205`）
- `ip -o link show | grep oray_vnc` 有设备、`mtu 1300`
- 重启一次仍然成立（不成立就是 `pgyvpn_guard.sh` 没跑起来，看 `logread | grep pgyvpn`）
