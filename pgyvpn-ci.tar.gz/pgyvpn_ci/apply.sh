#!/bin/sh
# 在 padavan-4.4 仓库根目录执行：sh apply.sh
# 作用：把蒲公英(pgyvpn)插件接进源码树，云编译/本地编译时随固件一起打包
set -e

REPO="${1:-.}"
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$REPO" || exit 1
[ -d trunk/user ] || { echo "用法: sh apply.sh /path/to/padavan-4.4"; exit 1; }

# 1. 插件文件树
mkdir -p trunk/user/pgyvpn
cp -a "$HERE/user_pgyvpn/payload" trunk/user/pgyvpn/
cp -f "$HERE/user_pgyvpn/Makefile" trunk/user/pgyvpn/Makefile

# 2. user/Makefile 挂载 + dev_init 钩子 + 配置开关 + 菜单
python3 - <<'PY'
import io, os, re, sys

def read(p):
    with io.open(p, encoding='utf-8', errors='replace') as f:
        return f.read()

def write(p, s):
    with io.open(p, 'w', encoding='utf-8', newline='\n') as f:
        f.write(s)

ok = []

# ---- 2.1 user/Makefile: 在 scripts 之后加入 pgyvpn（必须排在 www 之后）----
p = 'trunk/user/Makefile'
s = read(p)
if 'pgyvpn' not in s:
    m = re.search(r'^dir_y[ \t]*\+=[ \t]*scripts[ \t]*$', s, re.M)
    if not m:
        print('!! user/Makefile 里找不到 dir_y += scripts，请手工加一行'); sys.exit(1)
    line = '\ndir_$(CONFIG_FIRMWARE_INCLUDE_PGYVPN)\t\t+= pgyvpn'
    s = s[:m.end()] + line + s[m.end():]
    write(p, s); ok.append('user/Makefile')

# ---- 2.2 build_firmware_modify: 支持 PGYVPN=y 环境变量开开关 ----
p = 'trunk/build_firmware_modify'
s = read(p)
if 'CONFIG_FIRMWARE_INCLUDE_PGYVPN' not in s:
    anchor = '\nROOTDIR=`pwd`'
    if anchor not in s:
        print('!! build_firmware_modify 里找不到 ROOTDIR 锚点'); sys.exit(1)
    block = ('\n# 云编译/本地编译通过环境变量开关蒲公英插件: PGYVPN=y\n'
             'if [ "$PGYVPN" = "y" ] || [ "$PGYVPN" = "1" ] ; then\n'
             '\tgrep -q "^CONFIG_FIRMWARE_INCLUDE_PGYVPN=y" .config 2>/dev/null || \\\n'
             '\t\techo "CONFIG_FIRMWARE_INCLUDE_PGYVPN=y" >> .config\n'
             'fi\n')
    s = s.replace(anchor, block + anchor, 1)
    write(p, s); ok.append('build_firmware_modify')

# ---- 2.3 dev_init.sh: storage 就绪后补齐登录文件 ----
p = 'trunk/user/scripts/dev_init.sh'
s = read(p)
if 'pgyvpn_install.sh' not in s:
    anchor = '# fill storage\nmtd_storage.sh fill\n'
    if anchor not in s:
        print('!! dev_init.sh 里找不到 mtd_storage.sh fill 锚点'); sys.exit(1)
    block = anchor + ('\n# 蒲公英：把凭据/静态路由/自愈脚本铺到 /etc/storage\n'
                      'if [ -x /usr/bin/pgyvpn_install.sh ] ; then\n'
                      '\t/usr/bin/pgyvpn_install.sh\n'
                      'fi\n')
    s = s.replace(anchor, block, 1)
    write(p, s); ok.append('scripts/dev_init.sh')

# ---- 2.4 菜单: 高级菜单组 6 追加“蒲公英” ----
p = 'trunk/user/www/n56u_ribbon_fixed/state.js'
s = read(p)
if '"蒲公英");' in s or "'蒲公英';" in s:
    print('state.js 菜单已是「蒲公英」，跳过')
elif '蒲公英 VPN' in s:
    write(p, s.replace('蒲公英 VPN', '蒲公英')); ok.append('www/state.js')
    print('state.js 旧菜单名「蒲公英 VPN」已改成「蒲公英」')
else:
    lines = s.split('\n')
    done = 0
    for i, ln in enumerate(lines):
        if re.match(r'tabtitle\[6\]\s*=\s*new Array\("', ln) and ln.rstrip().endswith(');'):
            lines[i] = ln.rstrip()[:-2] + ', "蒲公英");'
            done += 1
        if re.match(r'tablink\[6\]\s*=\s*new Array\("', ln) and ln.rstrip().endswith(');'):
            lines[i] = ln.rstrip()[:-2] + ', "pgyvpn.asp");'
            done += 1
    if done != 2:
        print('!! state.js 菜单锚点未按预期匹配(%d/2)' % done); sys.exit(1)
    write(p, '\n'.join(lines)); ok.append('www/state.js')

print('已打补丁: ' + (', '.join(ok) if ok else '(都已存在，跳过)'))
PY

# 3. 云编译 workflow
mkdir -p .github/workflows
cp -f "$HERE/workflows/build-pgyvpn.yml" .github/workflows/build-pgyvpn.yml

echo
echo "完成。提交前检查: git status / git diff --stat"
echo "本地编译示例: cd trunk && PGYVPN=y fakeroot ./build_firmware_modify MI-R3G"
