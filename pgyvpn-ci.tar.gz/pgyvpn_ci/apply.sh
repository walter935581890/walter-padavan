#!/bin/sh
# =============================================================================
# 蒲公英(pgyvpn) 云编译集成脚本  v3
#
# 用途：在 padavan 源码树根目录执行，把蒲公英插件接进源码树，
#       之后 GitHub Actions / 本地 build_firmware_modify 编出来的 trx 就自带蒲公英。
#
# 用法：
#   sh apply.sh /opt/rt-n56u          # 云编译里用法（workflow 现在就是这么调的）
#   sh apply.sh .                     # 在源码树根目录直接执行
#
# 与本地固件（T1HC5661_3.4.3.9-099-精简版-v14.trx）一致的最终效果：
#   1. 蒲公英页面 = trunk/user/pgyvpn，装到 /usr/bin/pgyvpn /usr/share/pgyvpn
#   2. 菜单：蒲公英挂在「穿透服务」组，和 zerotier / aliddns / ddnsto / wireguard 并列
#   3. 蒲公英页面自带 <div id="Loading">，顶部系统信息能正常刷新
#   4. zerotier 页不再有重复标签条
#   5. 有「自定义菜单选项」页的源码树（3.4 系）多一个「穿透服务」总开关（复用 nvram w_ss）
#
# 兼容性：组索引不是写死的，脚本会先读出 Advanced_zerotier.asp 的 show_menu(5,L2,x)
#         反推 G=L2-1（4.4 系 G=16/L2=17，3.4 系 G=14/L2=15），再据此打补丁。
# 幂等：重复执行不会重复插入。
# =============================================================================
set -e

REPO="${1:-.}"
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$REPO" || exit 1
[ -d trunk/user ] || { echo "错误：$REPO 不像 padavan 源码树（缺 trunk/user）"; exit 1; }

WEB=""
for d in trunk/user/www/n56u_ribbon_fixed trunk/user/www/n56u_ribbon_fixed_nologo; do
	[ -f "$d/state.js" ] && { WEB="$d"; break; }
done
if [ -z "$WEB" ]; then
	for d in trunk/user/www/*/; do
		[ -f "${d}state.js" ] && { WEB="${d%/}"; break; }
	done
fi
[ -n "$WEB" ] || { echo "错误：找不到 www 目录下的 state.js"; exit 1; }
echo "== www 目录：$WEB"

# ------------------------------------------------------------------ 1. 插件本体
mkdir -p trunk/user/pgyvpn
cp -a "$HERE/user_pgyvpn/payload" trunk/user/pgyvpn/
cp -f "$HERE/user_pgyvpn/Makefile" trunk/user/pgyvpn/Makefile
echo "== 已铺入 trunk/user/pgyvpn（payload $(find trunk/user/pgyvpn/payload -type f | wc -l) 个文件）"

# ------------------------------------------------------- 2. 源码补丁（python）
PGY_WEB="$WEB" python3 - <<'PY'
import io, os, re, sys

WEB = os.environ['PGY_WEB']
ok, skip = [], []

def read(p):
    with io.open(p, encoding='utf-8', errors='replace') as f:
        return f.read()

def write(p, s):
    with io.open(p, 'w', encoding='utf-8', newline='\n') as f:
        f.write(s)

# ---- 2.0 定位「穿透服务」组在 state.js 里的索引 G 与二级菜单槽 L2 ----
st = read(WEB + '/state.js')
G = L2 = None

zp = WEB + '/Advanced_zerotier.asp'
if os.path.isfile(zp):
    m = re.search(r'show_menu\(\s*5\s*,\s*(\d+)\s*,', read(zp))
    if m:
        L2 = int(m.group(1)); G = L2 - 1

def group_holds(Gidx):
    """确认 tablink[Gidx] 里真的挂着 Advanced_zerotier.asp"""
    if re.search(r'tablink\[%d\]\.push\("Advanced_zerotier\.asp"\)' % Gidx, st):
        return True
    m = re.search(r'tablink\[%d\]\s*=\s*\(\s*([A-Za-z_]\w*)\s*\)' % Gidx, st)
    if m and re.search(r'%s\s*=\s*new Array\([^)]*Advanced_zerotier\.asp' % m.group(1), st):
        return True
    m = re.search(r'tablink\[%d\]\s*=\s*new Array\([^)]*Advanced_zerotier\.asp' % Gidx, st)
    return bool(m)

if G is not None and not group_holds(G):
    G = L2 = None

if G is None:
    m = re.search(r'tablink\[(\d+)\]\.push\("Advanced_zerotier\.asp"\)', st)
    if not m:
        m = re.search(r'tablink\[(\d+)\]\s*=\s*new Array\([^)]*Advanced_zerotier\.asp', st)
    if not m:
        for mm in re.finditer(r'tablink\[(\d+)\]\s*=\s*\(\s*([A-Za-z_]\w*)\s*\)', st):
            if re.search(r'%s\s*=\s*new Array\([^)]*Advanced_zerotier\.asp' % mm.group(2), st):
                m = mm; break
    if m:
        G = int(m.group(1)); L2 = G + 1

FORCE_APPEND = 0
if G is None:
    G, L2, FORCE_APPEND = 16, 17, 1
    print('!! 未找到 zerotier 所在分组，按 G=16 处理（蒲公英组会追加到二级菜单末尾）')
print('== 穿透服务组：tablink[%d]，二级菜单槽 menuL2[%d]' % (G, L2))

# ---- 2.1 user/Makefile：让 romfs 阶段把插件铺进去 ----
p = 'trunk/user/Makefile'
s = read(p)
if 'CONFIG_FIRMWARE_INCLUDE_PGYVPN' in s:
    skip.append('user/Makefile(已存在)')
else:
    m = re.search(r'^dir_y[ \t]*\+=[ \t]*scripts[ \t]*$', s, re.M)
    if not m:
        print('!! user/Makefile 里找不到 "dir_y += scripts" 锚点，请手工加一行：\n'
              '   dir_$(CONFIG_FIRMWARE_INCLUDE_PGYVPN) += pgyvpn'); sys.exit(1)
    s = s[:m.end()] + '\ndir_$(CONFIG_FIRMWARE_INCLUDE_PGYVPN)\t\t+= pgyvpn' + s[m.end():]
    write(p, s); ok.append('user/Makefile')

# ---- 2.2 build_firmware_modify：PGYVPN=y 环境变量开关 ----
p = 'trunk/build_firmware_modify'
s = read(p)
if 'CONFIG_FIRMWARE_INCLUDE_PGYVPN' in s:
    skip.append('build_firmware_modify(已存在)')
else:
    anchor = '\nROOTDIR=`pwd`'
    if anchor not in s:
        print('!! build_firmware_modify 里找不到 ROOTDIR 锚点，请手工添加 PGYVPN 开关'); sys.exit(1)
    block = ('\n# 蒲公英插件开关（云编译 workflow 用环境变量打开）: PGYVPN=y\n'
             'if [ "$PGYVPN" = "y" ] || [ "$PGYVPN" = "1" ] ; then\n'
             '\tgrep -q "^CONFIG_FIRMWARE_INCLUDE_PGYVPN=y" .config 2>/dev/null || \\\n'
             '\t\techo "CONFIG_FIRMWARE_INCLUDE_PGYVPN=y" >> .config\n'
             'fi\n')
    s = s.replace(anchor, block + anchor, 1)
    write(p, s); ok.append('build_firmware_modify')

# ---- 2.3 dev_init.sh：开机把凭据/路由铺到 /etc/storage ----
p = 'trunk/user/scripts/dev_init.sh'
s = read(p)
if 'pgyvpn_install.sh' in s:
    skip.append('scripts/dev_init.sh(已存在)')
else:
    anchor = 'mtd_storage.sh fill\n'
    if anchor not in s:
        print('!! dev_init.sh 里找不到 "mtd_storage.sh fill" 锚点'); sys.exit(1)
    block = anchor + ('\n# 蒲公英：把账号/静态路由/自愈脚本铺到 /etc/storage\n'
                      'if [ -x /usr/bin/pgyvpn_install.sh ] ; then\n'
                      '\t/usr/bin/pgyvpn_install.sh\n'
                      'fi\n')
    s = s.replace(anchor, block, 1)
    write(p, s); ok.append('scripts/dev_init.sh')

# ---- 2.4 state.js：菜单归位 ----
p = WEB + '/state.js'
s = read(p)
orig = s

# (a) 旧包(v1)会把蒲公英塞进「系统管理」组（tabtitle[6]/tablink[6]），先摘掉
s = re.sub(r'(tabtitle\[6\]\s*=\s*new Array\([^\n]*?),\s*"蒲公英"', r'\1', s, count=1)
s = re.sub(r'(tablink\[6\]\s*=\s*new Array\([^\n]*?),\s*"pgyvpn\.asp"', r'\1', s, count=1)

# (b) 追加「挂到穿透服务组」的代码（放在文件末尾，避开各 fork 后面的 w_xxx 显隐块）
marker = '/* pgyvpn: attach to 穿透服务 group'
if marker not in s:
    block = '''
%s (tablink[%d]) */
function pgy_menu_attach(){
\tvar G = %d, L2 = %d;\n\t/* 3.4 系有「穿透服务」总开关(w_ss)：关掉时不挂菜单 */\n\tif (typeof w_ss != "undefined" && w_ss == \'0\') return;
\tif (typeof tabtitle[G] == "undefined" || !tabtitle[G]) tabtitle[G] = new Array("");
\tif (typeof tablink[G]  == "undefined" || !tablink[G])  tablink[G]  = new Array("");
\tvar have = 0, i;
\tfor (i = 1; i < tablink[G].length; i++)
\t\tif (tablink[G][i] == "pgyvpn.asp") have = 1;
\tif (!have) {
\t\ttabtitle[G].push("蒲公英");
\t\ttablink[G].push("pgyvpn.asp");
\t}
\t/* 二级菜单：槽位已经指向本组就复用，否则在末尾补一个「穿透服务」入口 */
\tvar reuse = (%d == 0) && (typeof menuL2_link != "undefined") && (menuL2_link[L2] == tablink[G][1]);
\tif (!reuse) {
\t\tmenuL2_title.push("<#menu5_30#>");   /* 穿透服务 */
\t\tmenuL2_link.push(tablink[G][1]);
\t}
}
pgy_menu_attach();
/* end pgyvpn menu */
''' % (marker, G, G, L2, FORCE_APPEND)
    s = s.rstrip('\n') + block
else:
    # 已打过补丁但组索引不同（换过 fork）→ 更新索引
    s = re.sub(r'pgyvpn: attach to 穿透服务 group \(tablink\[\d+\) \*/',
               'pgyvpn: attach to 穿透服务 group (tablink[%d]) */' % G, s, count=1)
    s = re.sub(r'\tvar G = \d+, L2 = \d+;', '\tvar G = %d, L2 = %d;' % (G, L2), s, count=1)
    s = re.sub(r'var reuse = \(\d+ == 0\)', 'var reuse = (%d == 0)' % FORCE_APPEND, s, count=1)

# (c) 带「自定义菜单选项」页的源码树：把 w_ss 显隐块指向「穿透服务」组
if 'var w_ss' in s:
    newblk = ("if (w_ss == '0'){   /* 关闭「穿透服务」整组（含蒲公英） */\n"
              "\tmenuL2_link[%d] = \"\";\n"
              "\tmenuL2_title[%d] = \"\";\n"
              "\ttabtitle[%d] = new Array(\"\");\n"
              "\ttablink[%d] = new Array(\"\");\n"
              "}\n") % (L2, L2, G, G)
    if newblk not in s:
        m = re.search(r'if\s*\(\s*w_ss\s*==\s*0\s*\)\s*\{\n(?:[^\n]*\n)*?\}\n', s)
        if m:
            if m.group(0) != newblk:
                s = s[:m.start()] + newblk + s[m.end():]
                ok.append('www/state.js(w_ss 指向穿透服务)')
        else:
            s = s.rstrip('\n') + '\n' + newblk
            ok.append('www/state.js(补 w_ss 显隐块)')

if s != orig:
    write(p, s); ok.append('www/state.js(菜单归位)')

# ---- 2.5 Advanced_zerotier.asp：去重复标签条 + 页签序号更正 ----
p = WEB + '/Advanced_zerotier.asp'
if os.path.isfile(p):
    s = read(p); o = s
    s = re.sub(r'show_menu\(\s*5\s*,\s*%d\s*,\s*0\s*\)' % L2,
               'show_menu(5,%d,1);' % L2, s)
    m = re.search(r'\n[ \t]*<ul class="nav nav-tabs"[^>]*>.*?</ul>[ \t]*\r?\n', s, re.S)
    if m and 'id="allink"' in m.group(0):
        s = s[:m.start()] + '\n' + s[m.end():]
    if s != o:
        write(p, s); ok.append('www/Advanced_zerotier.asp(去重标签条/页签序号)')
    else:
        skip.append('www/Advanced_zerotier.asp(无需改)')

# ---- 2.6 Advanced_web.asp：自定义菜单选项里的「穿透服务」开关 ----
p = WEB + '/Advanced_web.asp'
if os.path.isfile(p):
    s = read(p); o = s
    if 'name="w_ss"' in s:
        # 该 fork 本来就有 w_ss 开关（3.4 系原本是「科学上网」），改标签为「穿透服务」并强制显示
        mrow = re.search(r'<tr[^>]*id="row_wss"[^>]*>(.*?)</tr>', s, re.S)
        if mrow and '<th' in mrow.group(1) and '穿透服务' not in mrow.group(1):
            newth = '<th width="50%">穿透服务</th>'
            body = re.sub(r'<th[^>]*>.*?</th>', newth, mrow.group(1), count=1, flags=re.S)
            s = s[:mrow.start(1)] + body + s[mrow.end(1):]
            ok.append('www/Advanced_web.asp(开关标签改为穿透服务)')
        # 该行默认 display:none，只在装有 shadowsocks 时才显示 → 改为始终显示
        if re.search(r'showhide_div\(\s*\'row_wss\'\s*,\s*true\s*\)', s):
            m2 = re.search(r'if\s*\(\s*found_app_shadowsocks\(\)\s*\)\s*\{\s*showhide_div\(\s*\'row_wss\'\s*,\s*true\s*\)\s*;\s*\}', s)
            if m2:
                s = s[:m2.start()] + "showhide_div('row_wss', true);" + s[m2.end():]
                ok.append('www/Advanced_web.asp(穿透服务开关常显)')
        if "init_itoggle('w_ss')" not in s:
            m3 = re.search(r"[ \t]*init_itoggle\('w_[^']*'\);", s)
            if m3:
                s = s[:m3.end()] + "\n\tinit_itoggle('w_ss');" + s[m3.end():]
        if s == o:
            skip.append('www/Advanced_web.asp(已有穿透服务开关)')
        else:
            write(p, s)
            ok.append('www/Advanced_web.asp(开关写入)')
        # 若该页另有别的行也叫「穿透服务」（3.4 里 aliddns 行就叫这名），改名避免重名
        mrow2 = re.search(r'<tr[^>]*id="row_waliddns"[^>]*>(.*?)</td>', s, re.S)
        if mrow2 and '穿透服务' in mrow2.group(1):
            body2 = mrow2.group(1).replace('<th width="50%">穿透服务</th>',
                                           '<th width="50%">阿里DDNS</th>')
            s = s[:mrow2.start(1)] + body2 + s[mrow2.end(1):]
            write(p, s)
            ok.append('www/Advanced_web.asp(aliddns 行改名)')
    else:
        m = re.search(r'<th width="50%">广告管理</th>', s) or \
            re.search(r'<th width="50%">系统日志</th>', s)
        if not m:
            print('!! Advanced_web.asp 里找不到行锚点，跳过开关（不影响其他改动）')
        else:
            end = s.find('</tr>', m.end()) + len('</tr>')
            row = '''
\t\t\t\t\t\t\t\t\t\t<tr >
\t\t\t\t\t\t\t\t\t\t\t<th width="50%">穿透服务</th>
\t\t\t\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class="main_itoggle">
\t\t\t\t\t\t\t\t\t\t\t\t\t<div id="w_ss_on_of">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<input type="checkbox" id="w_ss_fake" <% nvram_match_x("", "w_ss", "1", "value=1 checked"); %><% nvram_match_x("", "w_ss", "0", "value=0"); %>  />
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t<div style="position: absolute; margin-left: -10000px;">
\t\t\t\t\t\t\t\t\t\t\t\t\t<input type="radio" value="1" name="w_ss" id="w_ss_1" class="input" <% nvram_match_x("", "w_ss", "1", "checked"); %> /><#checkbox_Yes#>
\t\t\t\t\t\t\t\t\t\t\t\t\t<input type="radio" value="0" name="w_ss" id="w_ss_0" class="input" <% nvram_match_x("", "w_ss", "0", "checked"); %> /><#checkbox_No#>
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t\t</tr>'''
            s = s[:end] + row + s[end:]
            if "init_itoggle('w_pdnsd');" in s:
                s = s.replace("init_itoggle('w_pdnsd');",
                              "init_itoggle('w_pdnsd');\n\tinit_itoggle('w_ss');", 1)
            elif "init_itoggle('w_ss')" not in s:
                m2 = re.search(r"\tinit_itoggle\('w_[^']*'\);", s)
                if m2:
                    s = s[:m2.end()] + "\n\tinit_itoggle('w_ss');" + s[m2.end():]
            write(p, s); ok.append('www/Advanced_web.asp(穿透服务开关)')
else:
    skip.append('www/Advanced_web.asp(本源码树无此页)')

print('已改: ' + (', '.join(ok) if ok else '无'))
if skip:
    print('跳过: ' + ', '.join(skip))
PY

# ------------------------------------------------------------ 3. 结果自检
echo "== 自检 =="
grep -n "CONFIG_FIRMWARE_INCLUDE_PGYVPN" trunk/user/Makefile
grep -n "pgyvpn_install.sh" trunk/user/scripts/dev_init.sh | head -2
printf 'state.js 命中 pgyvpn.asp：'; grep -c "pgyvpn.asp" "$WEB/state.js" || true
printf 'state.js 命中 蒲公英：'; grep -c "蒲公英" "$WEB/state.js" || true
printf 'Makefile 含 musl loader 软链：'; grep -c "ld-musl-mipsel-sf.so.1" trunk/user/pgyvpn/Makefile || true
printf 'pgyvpn.asp 里有 Loading 容器：'; grep -c 'id="Loading"' trunk/user/pgyvpn/payload/www/pgyvpn.asp || true
python3 - "$WEB/state.js" <<'PY'
import sys
p = sys.argv[1]
s = open(p, encoding='utf-8', errors='replace').read()
print('state.js 花括号平衡:', s.count('{') == s.count('}'),
      '| 圆括号平衡:', s.count('(') == s.count(')'))
print('state.js 注入块:', s.count('pgy_menu_attach()') >= 1)
PY
echo
echo "完成。提交后即可云编译："
echo "  git add -A && git commit -m 'pgyvpn: 挂到穿透服务组' && git push"
echo "本地编译示例："
echo "  cd trunk && PGYVPN=y fakeroot ./build_firmware_modify B70"
